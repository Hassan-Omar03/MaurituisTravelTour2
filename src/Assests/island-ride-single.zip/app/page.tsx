'use client';
import Image from 'next/image';

export default function Page(){
  return (
    <main className="min-h-screen">
      {/* Topbar */}
      <div className="bg-cyan-950 text-cyan-50">
        <div className="container flex items-center justify-between py-2 text-sm">
          <div className="space-x-5"><span>📧 emailus@gmail.com</span><span>📞 ph number</span></div>
          <a className="border border-emerald-400/60 rounded-lg px-3 py-1" href="#">WhatsApp Us</a>
        </div>
      </div>

      {/* Navbar */}
      <div className="sticky top-0 z-10 bg-white/90 backdrop-blur border-b">
        <div className="container flex items-center gap-4 py-3">
          <div className="flex items-center gap-2 font-bold">
            <Image alt="logo" width={36} height={36} className="rounded-full object-cover" src="/images/logo.png"/>
            <span>Mauritius Travel & Tour</span>
          </div>
          <nav className="flex-1 text-slate-700 hidden md:flex gap-5 justify-center">
            <a href="#home">Home</a><a href="#about">About</a><a href="#tours">Tours</a>
            <a href="#transfer">Airport Transfers</a><a href="#contact">Contact</a>
          </nav>
          <a className="btn btn-primary" href="#book">Book Now ›</a>
        </div>
      </div>

      {/* Hero */}
      <section id="home" className="relative h-[70vh] min-h-[460px]">
        <Image alt="hero" fill className="object-cover" priority src="/images/hero.jpg"/>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/50"/>
        <div className="container absolute inset-0 flex items-end pb-10 text-white">
          <div>
            <h1 className="text-3xl md:text-6xl font-semibold leading-tight">
              Taking you to the<br/>Best Places in Mauritius
            </h1>
            <a className="btn btn-ghost mt-4 border border-white/40" href="#book">Book Your Ride Now ›</a>
          </div>
        </div>
      </section>

      {/* About */}
      <section id="about" className="section bg-deep text-[var(--ink)]">
        <div className="container grid md:grid-cols-2 gap-7 items-center">
          <Image alt="lagoon" width={1200} height={900} className="rounded-xl object-cover" src="/images/about.jpg"/>
          <div>
            <p className="uppercase tracking-widest text-tealish text-xs mb-1">About Us</p>
            <h2 className="h2">Discover Your Next Adventure</h2>
            <p className="text-[var(--muted)] leading-relaxed mt-2">Welcome to Island Ride – Mauritius Travel & Tour, your trusted travel partner for over 10 years.</p>
            <p className="text-[var(--muted)] leading-relaxed mt-3">From airport transfers to private tours and daily commutes, our professional chauffeurs ensure you travel safely and in style.</p>
            <a className="btn btn-ghost mt-4" href="#about-more">Read More ›</a>
          </div>
        </div>
      </section>

      {/* Tours */}
      <section id="tours" className="section bg-white">
        <div className="container">
          <div className="md:flex items-center justify-between gap-6">
            <h2 className="h2 text-teal-900">Choose a Tour that satisfies your Soul</h2>
            <div className="flex gap-3 mt-4 md:mt-0 flex-wrap">
              <span className="chip chip-active">Airport Transfer</span>
              <span className="chip">Hotel Transfer</span>
              <span className="chip">Excursion</span>
              <span className="chip">Door Step Service</span>
            </div>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5 mt-6">
            {['/images/t1.jpg','/images/t2.jpg','/images/t3.jpg','/images/t4.jpg'].map((src,i)=> (
              <article key={i} className="card relative">
                <Image alt={'tour'+i} width={1200} height={800} className="h-60 w-full object-cover" src={src}/>
                <div className="p-4">
                  <h3 className="text-lg font-semibold">NORTH TOUR</h3>
                  <p className="text-teal-100/90 text-sm mt-1">Welcome to Mauritius Travel & Tours, your trusted partner for more than 10 years.</p>
                  <a className="btn btn-ghost mt-3 text-sm" href="#read">Read More ›</a>
                </div>
                <div className="absolute top-3 right-3 w-10 h-10 grid place-items-center rounded-full bg-[#0f2f33] text-cyan-50 font-bold">↗</div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Estimator */}
      <section id="transfer" className="section relative">
        <Image alt="plane" fill className="-z-10 object-cover" src="/images/plane.jpg"/>
        <div className="container text-cyan-50">
          <h2 className="h2">Choose a Tour that satisfies your Soul</h2>
          <div className="flex flex-wrap gap-3 mt-2">
            <div className="bg-white/20 rounded-xl px-4 py-2">🚗 Customised transfers</div>
            <div className="bg-white/20 rounded-xl px-4 py-2">👥 Multiple vehicles available</div>
          </div>
          <div className="ticket mt-5">
            <div><div className="text-xs text-cyan-100 mb-1">From</div>
              <select><option>Select Location</option><option>Airport</option><option>Port Louis</option><option>Flic-en-Flac</option></select>
            </div>
            <div className="text-center text-cyan-100 text-2xl">⇄</div>
            <div><div className="text-xs text-cyan-100 mb-1">To</div>
              <select><option>Select Location</option><option>Grand Baie</option><option>Tamarin</option><option>Le Morne</option></select>
            </div>
            <div className="text-center text-xl text-cyan-100">🌞 / 🌙</div>
          </div>
          <div className="inline-block mt-4 rounded-full border border-white/30 bg-black/50 px-5 py-3">Estimated Price – for up to 4 Persons</div>
        </div>
      </section>

      {/* Organizer */}
      <section className="section bg-deep text-[var(--ink)]">
        <div className="container grid md:grid-cols-2 gap-6 items-center">
          <div>
            <p className="uppercase tracking-widest text-tealish text-xs mb-1">Meet the Organizer</p>
            <h2 className="h2">The Vision Behind It All</h2>
            <p className="text-[var(--muted)] mt-2">Behind every successful event is a passionate team working hand-in-hand to make each experience memorable.</p>
          </div>
          <div className="bg-[#0f3540] rounded-2xl p-4 text-center">
            <Image alt="organizer" width={140} height={140} className="rounded-xl mx-auto object-cover" src="/images/organizer.jpg"/>
            <div className="font-semibold mt-2">ADIL & GROUP</div>
            <div className="text-sm text-teal-200/90">Founder, Mauritius Travel & Tour</div>
          </div>
        </div>
        <div id="book" className="container text-center mt-8">
          <div className="inline-block bg-[#0f3540] text-cyan-100 rounded-xl px-4 py-2 m-2">Have custom requests?</div>
          <div className="inline-block bg-[#0f3540] text-cyan-100 rounded-xl px-4 py-2 m-2">Friends & family packages?</div>
          <div className="inline-block bg-[#0f3540] text-cyan-100 rounded-xl px-4 py-2 m-2">Flexible options available</div>
          <div className="mt-4"><a className="btn btn-primary px-7 py-3" href="#" target="_blank">WhatsApp Us</a></div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-[#071f24] text-cyan-100">
        <div className="container grid md:grid-cols-2 lg:grid-cols-4 gap-6 py-10">
          <div><h3 className="text-white text-xl font-semibold mb-2">Travel With Us</h3>
            <p>Welcome to Island Ride, your trusted partner for transfers and tours in Mauritius.</p>
            <div className="opacity-70 mt-2">● ● ● ●</div></div>
          <div><h4 className="text-white font-semibold mb-2">Quick Links</h4>
            <ul className="space-y-1"><li><a href="#tours">Tour</a></li><li><a href="#transfer">Airport Transfer</a></li><li><a href="#about">About</a></li></ul></div>
          <div><h4 className="text-white font-semibold mb-2">Support</h4>
            <ul className="space-y-1"><li><a href="#">Contact Us</a></li><li><a href="#">Privacy Policy</a></li><li><a href="#">Terms & Conditions</a></li></ul></div>
          <div><h4 className="text-white font-semibold mb-2">Communication</h4>
            <ul className="space-y-1"><li>📧 emailus@gmail.com</li><li>📞 phone number</li></ul></div>
        </div>
        <div className="border-t border-white/10 text-center text-teal-200 py-3">© {new Date().getFullYear()} Mauritius Travel & Tour</div>
      </footer>
    </main>
  )
}
